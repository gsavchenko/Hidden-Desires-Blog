CREATE DATABASE  IF NOT EXISTS `BlogSiteDb` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `BlogSiteDb`;
-- MySQL dump 10.13  Distrib 5.7.9, for osx10.9 (x86_64)
--
-- Host: localhost    Database: BlogSiteDb
-- ------------------------------------------------------
-- Server version	5.7.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Blog`
--

DROP TABLE IF EXISTS `Blog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Blog` (
  `idBlog` int(11) NOT NULL AUTO_INCREMENT,
  `data` blob NOT NULL,
  `time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`idBlog`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Blog`
--

LOCK TABLES `Blog` WRITE;
/*!40000 ALTER TABLE `Blog` DISABLE KEYS */;
INSERT INTO `Blog` VALUES (1,'Test Entry 1','2016-04-16 03:00:18'),(2,'Test Entry 2','2016-04-16 03:01:32'),(3,'this is test 4','2016-04-18 13:06:19'),(4,'this is test to show that this works','2016-04-18 13:09:25'),(5,'today i have a samsung meeting that i have to go to. there i will explain all the cool stuff my team and i developed for there samsung printer the mx7 Printer!','2016-04-18 13:23:17'),(6,'ta;ldjfl;asjdf;lajs;ldfj;lasjd;lfjas;ldjf;lasjd;flja;sldjf;lajsd ;la s;daeaerhiuerkueriueriuaerio;','2016-04-18 13:26:55'),(7,'yet abother entry ','2016-04-18 13:40:15'),(8,'This is another post test','2016-04-19 12:51:20'),(9,'asjd�fjas�djfl�asjdf�lajsl�dfasdfaskdfj a�4�random ','2016-04-19 12:54:21'),(10,'test','2016-04-19 13:20:14'),(11,'oasdfas;dklfa;lsdfjalsdmfaosdjfaosdjfaslidjflasjdflasjdlfa','2016-04-19 13:21:47'),(12,'blah','2016-04-19 13:22:37'),(13,'hello ','2016-04-19 13:26:14'),(14,'aasdfasdfasdf','2016-04-19 13:38:05'),(15,'asdfasdfasdfasdfasdfaasdfas','2016-04-19 13:39:11'),(16,'this is a entry for the blog','2016-04-19 14:52:29'),(17,'asdfasdfooiqoioqoiqewou09q8029379481273412341234','2016-04-19 14:54:29'),(18,'hi','2016-04-19 14:55:42'),(19,'this is kevin for the billionth time writing something on this blog','2016-04-19 14:58:51'),(20,'this is kevin for the billionth and one time that i write something on this blog ','2016-04-19 14:59:59'),(21,'this is kevin for the billionth and one time that i write something on this blog fwgrtgwgw','2016-04-19 15:00:43'),(22,'this is blob','2016-04-19 15:06:08'),(23,'/Users/kevincornejoandrade/Pictures/37DC075C1.jpg','2016-04-19 15:06:58'),(24,'whats up my homies ','2016-04-19 15:11:04');
/*!40000 ALTER TABLE `Blog` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-04-19 15:30:26
